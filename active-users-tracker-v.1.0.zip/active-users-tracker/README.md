---
=== Active Users Tracker === 
Contributors: (Alex Elph) 
Tags: users, activity, tracking 
Requires at least: 6.0 
Tested up to: 6.7.1 
Stable tag: 1.0.0 
License: GPLv2 or later 
License URI: http://www.gnu.org/licenses/gpl-2.0.html  
---

# Плагин для отслеживания активности пользователей WordPress.

Отслеживание активности пользователей по следующим действиям:

1. Вход в систему (last_login)
2. Публикация или редактирование поста (save_post)
3. Написание комментария (last_comment)
4. Любое действие в админ-панели (last_activity)

Никакого дополнительного логирования не используется. 
Все параметры берутся из стандартных переменных WordPress.

Плагин полностью написан промптами для Claude 3.5 Sonnet в редакторе Windsurf, с редкими ручными правками, в тех местах, где он не справлялся.